def crear_tablero(filas, columnas):
    """
    Crea un tablero de ajedrez con las dimensiones especificadas.
    
    Args:
    filas (int): Número de filas del tablero.
    columnas (int): Número de columnas del tablero.
    
    Returns:
    list: Una matriz que representa el tablero de ajedrez.
    """
    tablero = []
    for fila in range(filas):
        fila_actual = []
        for columna in range(columnas):
            valor = "  " if (fila + columna) % 2 == 0 else " "
            fila_actual.append(valor)
        tablero.append(fila_actual)
    return tablero

def movimientos_caballo(posicion_fila, posicion_columna):
    """
    Calcula los movimientos válidos para un caballo en una posición dada.
    
    Args:
    posicion_fila (int): La fila actual del caballo (1-8).
    posicion_columna (int): La columna actual del caballo (0-7).
    
    Returns:
    list: Una lista de tuplas con los movimientos válidos del caballo.
    """
    movimientos_validos = []
    movimientos_posibles = [(1, 2), (1, -2), (-1, 2), (-1, -2), (2, 1), (2, -1), (-2, 1), (-2, -1)]
    for desplazamiento_fila, desplazamiento_columna in movimientos_posibles:
        nueva_fila, nueva_columna = posicion_fila + desplazamiento_fila, posicion_columna + desplazamiento_columna
        if 1 <= nueva_fila <= 8 and 1 <= nueva_columna <= 8:
            letra_columna = chr(ord('a') + nueva_columna - 1)
            movimientos_validos.append((nueva_fila, letra_columna))
    return movimientos_validos

def imprimir_tablero(tablero):
    """
    Imprime el tablero de ajedrez en consola.
    
    Args:
    tablero (list): La matriz que representa el tablero de ajedrez.
    """
    letras_columnas = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h']
    print("   " + "   ".join(letras_columnas))  
    print("  ╔═══" + "╦═══" * (len(letras_columnas) - 1) + "╗")  
    for fila_indice, fila in enumerate(tablero):
        print(f"{8 - fila_indice} ║", end="")  
        for columna_indice, celda in enumerate(fila):
            if len(celda.strip()) == 0:
                print(f"   ", end="")
            else:
                print(f" {celda} ", end="")
            print("║", end="")  
        print()  
        if fila_indice < len(tablero) - 1:
            print("  ╠═══" + "╬═══" * (len(letras_columnas) - 1) + "╣")  
        else:
            print("  ╚═══" + "╩═══" * (len(letras_columnas) - 1) + "╝")

def solicitar_coordenada_fila():
    """
    Solicita al usuario una coordenada válida de fila para el caballo.
    
    Returns:
    int: La fila ingresada por el usuario (1-8).
    """
    while True:
        try:
            fila = int(input("Ingrese coordenadas del caballo en filas (1 al 8):\n"))
            if 1 <= fila <= 8:
                return fila
            else:
                print("Por favor, ingrese un número entre 1 y 8.")
        except ValueError:
            print("Por favor, ingrese un número válido.")

def solicitar_coordenada_columna():
    """
    Solicita al usuario una coordenada válida de columna para el caballo.
    
    Returns:
    str: La columna ingresada por el usuario ('a'-'h').
    """
    while True:
        columna = input("Ingrese coordenadas del caballo en columnas (a a h) en minúsculas:\n").strip().lower()
        if columna in ["a", "b", "c", "d", "e", "f", "g", "h"]:
            return columna
        else:
            print("Por favor, ingrese una letra entre 'a' y 'h'.")

def solicitar_color_caballo():
    """
    Solicita al usuario el color del caballo.
    
    Returns:
    str: El color del caballo ('Blanco' o 'Negro').
    """
    colores = {
        1: "Blanco",
        2: "Negro"
    }
    while True:
        try:
            opcion = int(input("Ingrese el color del caballo (1: Blanco, 2: Negro):\n"))
            if opcion in colores:
                return colores[opcion]
            else:
                print("Opción inválida, ingrese una opción válida.")
        except ValueError:
            print("Por favor, ingrese un número válido.")

def agregar_caballo(tablero):
    """
    Agrega un caballo al tablero en la posición y con el color especificado por el usuario.
    
    Args:
    tablero (list): La matriz que representa el tablero de ajedrez.
    
    Returns:
    list: El tablero con el caballo agregado.
    """
    print("Agregar caballo")
    global fila_caballo, columna_caballo_real
    fila_caballo = solicitar_coordenada_fila()
    columna_caballo = solicitar_coordenada_columna()
    columna_caballo_real = ord(columna_caballo) - ord('a')
    color_caballo = solicitar_color_caballo()
    tablero[fila_caballo - 1][columna_caballo_real] = f"C{color_caballo[0]}"
    return tablero

def solicitar_tipo_pieza():
    """
    Solicita al usuario el tipo de pieza a agregar.
    
    Returns:
    str: El tipo de pieza ('P', 'A', 'C', 'T', 'R', 'K').
    """
    piezas = {
        1: "P",
        2: "A",
        3: "C",
        4: "T",
        5: "R",
        6: "K"
    }
    while True:
        try:
            opcion = int(input("Ingrese el tipo de pieza (1: Peón, 2: Alfil, 3: Caballo, 4: Torre, 5: Reina, 6: Rey):\n"))
            if opcion in piezas:
                return piezas[opcion]
            else:
                print("Opción inválida, ingrese una opción válida.")
        except ValueError:
            print("Por favor, ingrese un número válido.")

def solicitar_color_pieza():
    """
    Solicita al usuario el color de la pieza a agregar.
    
    Returns:
    str: El color de la pieza ('Blanco' o 'Negro').
    """
    colores = {
        1: "Blanco",
        2: "Negro"
    }
    while True:
        try:
            opcion = int(input("Ingrese el color de la pieza (1: Blanco, 2: Negro):\n"))
            if opcion in colores:
                return colores[opcion]
            else:
                print("Opción inválida, ingrese una opción válida.")
        except ValueError:
            print("Por favor, ingrese un número válido.")

def agregar_piezas(tablero, cantidad_piezas):
    """
    Agrega una cantidad específica de piezas al tablero en las posiciones y con los tipos y colores especificados por el usuario.
    
    Args:
    tablero (list): La matriz que representa el tablero de ajedrez.
    cantidad_piezas (int): La cantidad de piezas a agregar.
    
    Returns:
    list: El tablero con las piezas agregadas.
    """
    for i in range(cantidad_piezas):
        print(f"Agregar pieza {i + 1}")
        fila_pieza = solicitar_coordenada_fila()
        columna_pieza = solicitar_coordenada_columna()
        columna_pieza_real = ord(columna_pieza) - ord('a')
        tipo_pieza = solicitar_tipo_pieza()
        color_pieza = solicitar_color_pieza()
        tablero[fila_pieza - 1][columna_pieza_real] = f"{tipo_pieza}{color_pieza[0]}"
    return tablero

# Crear el tablero vacío
tablero = crear_tablero(8, 8)
# Agregar el caballo al tablero
tablero = agregar_caballo(tablero)

# Solicitar la cantidad de piezas adicionales a agregar
while True:
    try:
        cantidad_piezas = int(input("Ingrese la cantidad de piezas que quiere agregar al tablero (0 a 32): "))
        if 0 <= cantidad_piezas <= 32:
            break
        else:
            print("Por favor, ingrese un número entre 0 y 32.")
    except ValueError:
        print("Por favor, ingrese un número válido.")

# Agregar las piezas adicionales al tablero
tablero = agregar_piezas(tablero, cantidad_piezas)

# Obtener y mostrar los movimientos válidos del caballo
movimientos_validos = movimientos_caballo(fila_caballo, columna_caballo_real)
print("Movimientos disponibles para el caballo:")
for movimiento in movimientos_validos:
    print(f"Fila: {movimiento[0]}, Columna: {movimiento[1]}")

# Imprimir el tablero final
imprimir_tablero(tablero)
